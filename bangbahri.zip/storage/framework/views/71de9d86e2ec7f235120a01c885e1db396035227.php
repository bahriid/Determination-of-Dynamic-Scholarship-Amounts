<?php $__env->startSection('content'); ?>
  <h3>Pengaturan Rules Fuzzy 1</h3>
  <form class="form-horizontal" action="<?php echo e(action('FuzzysetController@updateForm', [$fuzzyset->id])); ?>" method="get">
  <div class="form-group">
    <label for="competitorPrice" class="col-sm-2 control-label">Penghasilan Orang Tua</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="competitorPrice" value="<?php echo e($fuzzyset->penghasilan_orangtua); ?>" readonly="readonly">
    </div>
  </div>
  <div class="form-group">
    <label for="beforePrice" class="col-sm-2 control-label">Nilai Akademik</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="beforePrice" value="<?php echo e($fuzzyset->nilai_akademik); ?>" readonly="readonly">
    </div>
  </div>
  <div class="form-group">
    <label for="currentPrice" class="col-sm-2 control-label">Point Sertifikat</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="currentPrice" value="<?php echo e($fuzzyset->poin_sertifikat); ?>" readonly="readonly">
    </div>
  </div>
  <div class="form-group">
    <label for="thenPrice" class="col-sm-2 control-label">Then</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="thenPrice" value="<?php echo e($fuzzyset->result_price); ?>" readonly="readonly">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Edit</button>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>