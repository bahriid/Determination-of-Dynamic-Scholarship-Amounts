<?php $__env->startSection('content'); ?>
  <h3>Pengaturan Range Fuzzy 1</h3>
  <table class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>Id</th>
        <th>Range</th>
        <th>Batas Bawah</th>
        <th>Batas Atas</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($fuzzyranges as $fuzzyrange): ?>
      <tr>
        <td><?php echo e($fuzzyrange->id); ?></td>
        <td><?php echo e($fuzzyrange->code); ?></td>
        <td><?php echo e($fuzzyrange->min); ?></td>
        <td><?php echo e($fuzzyrange->max); ?></td>
        <td><a href="<?php echo e(action('FuzzyrangeController@showRange', [$fuzzyrange->id])); ?>" class="btn btn-default">Show</a></td>
    <?php endforeach; ?>
    <tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>