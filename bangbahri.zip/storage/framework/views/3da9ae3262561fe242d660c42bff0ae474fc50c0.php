<?php $__env->startSection('content'); ?>
  <h3>Daftar Data Pengguna</h3>
  <div class="list-main-btn">
    <a href="<?php echo e(action('UserController@createForm')); ?>" class="btn btn-success">Tambah Data Pengguna</a>
  </div>
  <table class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>Level</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($users as $user): ?>
      <tr>
        <td><?php echo e($user->id); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td>
          <?php if($user->level == "ADMIN"): ?>
            Admin
          <?php elseif($user->level == "SEKRE"): ?>
            Sekretaris
          <?php else: ?> 
            <?php echo e($user->level); ?>

          <?php endif; ?>
        </td>
        <td>
          <form class="list-action" method="get" action="<?php echo e(action('UserController@showUser', [$user->id])); ?>">
            <button type="submit" class="btn btn-default">Show</button>
          </form>
          <form class="list-action" method="post" action="<?php echo e(action('UserController@deleteUser', [$user->id])); ?>">
            <?php echo e(csrf_field()); ?>

            <button type="submit" class="btn btn-danger">Delete</button>
          </form>
        </td>
    <?php endforeach; ?>
    <tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>