<?php $__env->startSection('content'); ?>
  <h3>Pengaturan Rules Fuzzy 1</h3>
    <table class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>Id</th>
        <th>Penghasilan Orang Tua</th>
        <th>Nilai Akademik</th>
        <th>Point Sertifikat</th>
        <th>Then</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($fuzzysets as $fuzzyset): ?>
      <tr>
        <td><?php echo e($fuzzyset->id); ?></td>
        <td><?php echo e($fuzzyset->penghasilan_orangtua); ?></td>
        <td><?php echo e($fuzzyset->nilai_akademik); ?></td>
        <td><?php echo e($fuzzyset->poin_sertifikat); ?></td>
        <td><?php echo e($fuzzyset->result_price); ?></td>
        <td><a href="<?php echo e(action('FuzzysetController@showSet', [$fuzzyset->id])); ?>" class="btn btn-default">Show</a></td>
    <?php endforeach; ?>
    <tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>