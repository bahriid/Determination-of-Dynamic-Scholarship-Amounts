<?php $__env->startSection('content'); ?>
  <h3>Pengaturan Rules Fuzzy 1</h3>
  <form class="form-horizontal" action="<?php echo e(action('FuzzysetController@updateSet', [$fuzzyset->id])); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
      <label for="competitorPrice" class="col-sm-2 control-label">Harga Kompetitor</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="competitorPrice" value="<?php echo e($fuzzyset->competitor_price); ?>" readonly="readonly">
      </div>
    </div>
    <div class="form-group">
      <label for="beforePrice" class="col-sm-2 control-label">Harga Sebelumnya</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="beforePrice" value="<?php echo e($fuzzyset->before_price); ?>" readonly="readonly">
      </div>
    </div>
    <div class="form-group">
      <label for="currentPrice" class="col-sm-2 control-label">Biaya Produksi</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="currentPrice" value="<?php echo e($fuzzyset->current_price); ?>" readonly="readonly">
      </div>
    </div>
    <div class="form-group">
      <label for="thenPrice" class="col-sm-2 control-label">Then</label>
      <div class="col-sm-10">
        <select class="form-control" id="thenPrice" name="result_price">
          <option value="LOW" <?php echo e(("LOW" == $fuzzyset->result_price) ? 'selected="selected"' : ''); ?>>LOW</option>
          <option value="MID" <?php echo e(("MID" == $fuzzyset->result_price) ? 'selected="selected"' : ''); ?>>MID</option>
          <option value="HIGH" <?php echo e(("HIGH" == $fuzzyset->result_price) ? 'selected="selected"' : ''); ?>>HIGH</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Simpan</button>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>