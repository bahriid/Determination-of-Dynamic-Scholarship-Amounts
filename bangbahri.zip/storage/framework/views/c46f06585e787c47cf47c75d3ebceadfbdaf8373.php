<?php $__env->startSection('content'); ?>
  <h3>Pengaturan Range Fuzzy 2</h3>
  <form class="form-horizontal" action="<?php echo e(action('Fuzzy2rangeController@updateForm', [$fuzzyrange->id])); ?>" method="get">
    <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Range</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="state" value="<?php echo e($fuzzyrange->code); ?>" readonly="readonly">
      </div>
    </div>
    <div class="form-group">
      <label for="minValue" class="col-sm-2 control-label">Batas Bawah</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="minValue" value="<?php echo e($fuzzyrange->min); ?>" readonly="readonly">
      </div>
    </div>
    <div class="form-group">
      <label for="maxValue" class="col-sm-2 control-label">Batas Atas</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="maxValue" value="<?php echo e($fuzzyrange->max); ?>" readonly="readonly">
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Edit</button>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>