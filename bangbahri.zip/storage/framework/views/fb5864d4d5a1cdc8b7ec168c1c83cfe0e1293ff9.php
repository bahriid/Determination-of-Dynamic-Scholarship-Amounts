<?php $__env->startSection('content'); ?>
  <h3><a href="<?php echo e(action('UserController@listUser')); ?>">Data Pengguna</a> | Menambah Data Pengguna</h3>
  <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
    <ul>
      <?php foreach($errors->all() as $error): ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>
  <form class="form-horizontal" action="<?php echo e(action('UserController@createUser')); ?>" method="post">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label for="userName" class="col-sm-2 control-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="userName" placeholder="Nama User" name="name" value="<?php echo e(old('name')); ?>">
    </div>
  </div>
  <div class="form-group">
    <label for="userEmail" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="userEmail" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
    </div>
  </div>
  <div class="form-group">
    <label for="userPassword" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="userPassword" placeholder="Password" name="password">
    </div>
  </div>
  <div class="form-group">
    <label for="userLevel" class="col-sm-2 control-label">Level</label>
    <div class="col-sm-10">
      <select class="form-control" id="userLevel" name="level">
        <option value="ADMIN" <?php echo e(("ADMIN" == old("level")) ? 'selected="selected"' : ''); ?>>Admin</option>
      </select>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Simpan</button>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>